const _0x45aa9e=_0x3bf7;(function(_0x6be7ba,_0x67776b){const _0x31d9a=_0x3bf7,_0x34ec55=_0x6be7ba();while(!![]){try{const _0x284e52=-parseInt(_0x31d9a(0xde))/(-0x255*-0x6+-0x1ce4+0xee7)*(-parseInt(_0x31d9a(0x121))/(-0x21*-0x6f+-0x24fb+0x16ae*0x1))+-parseInt(_0x31d9a(0xea))/(-0x551+-0x2363+0x28b7)*(-parseInt(_0x31d9a(0xd3))/(0x2344+0x9b7+-0x2cf7))+-parseInt(_0x31d9a(0x106))/(0x2*-0xa3d+-0x10fd+0x257c)*(-parseInt(_0x31d9a(0x111))/(0x2447+0x207*-0x3+0x1*-0x1e2c))+-parseInt(_0x31d9a(0xb7))/(0x2255+-0x2b1*-0x7+-0x3525)*(-parseInt(_0x31d9a(0x104))/(-0x1f66+-0x7a3*0x1+-0x49*-0x89))+parseInt(_0x31d9a(0x125))/(0xb0e+0xcc6+-0x17cb)+parseInt(_0x31d9a(0xd4))/(-0x16*-0xbf+-0x4eb+-0xb75)+-parseInt(_0x31d9a(0xc8))/(-0x7cf+0x16eb*0x1+-0xf11);if(_0x284e52===_0x67776b)break;else _0x34ec55['push'](_0x34ec55['shift']());}catch(_0x1238a6){_0x34ec55['push'](_0x34ec55['shift']());}}}(_0x49cc,-0x227f*-0x45+0xe367+-0x2*-0x1247c));function _0x3bf7(_0x315e93,_0x336013){const _0x4c4057=_0x49cc();return _0x3bf7=function(_0x215686,_0x5c0e47){_0x215686=_0x215686-(0xe*-0x289+-0x1a*-0x57+0x3*0x91d);let _0x7b6d9a=_0x4c4057[_0x215686];return _0x7b6d9a;},_0x3bf7(_0x315e93,_0x336013);}const {adams}=require(_0x45aa9e(0xd1)+_0x45aa9e(0x100)),Heroku=require(_0x45aa9e(0xb0)+_0x45aa9e(0xe7)),{readdirSync}=require('fs'),heroku=new Heroku({'token':process[_0x45aa9e(0x115)][_0x45aa9e(0xcd)+_0x45aa9e(0xdb)]}),appName=process[_0x45aa9e(0x115)][_0x45aa9e(0xef)+_0x45aa9e(0xe3)],BaseUrl=process[_0x45aa9e(0x115)][_0x45aa9e(0x11f)],adamsapikey=process[_0x45aa9e(0x115)][_0x45aa9e(0xbc)];function _0x49cc(){const _0x32dfe5=['964jKCUxn','15160750UIELJB','to\x20fetch\x20H','Error\x20upda','KsmtK','HSTNE','ARS*\x0a\x0a✅\x20*H','u\x20var\x20or\x20r','_KEY','includes','`setvar\x20VA','18TENqse','er.','wait\x20for\x20o','his\x20comman','`setvar\x20AU','_NAME','tlRzh','ironment\x20v','able\x20Updat','ent','ckguQ','uqxld','4926aIlzQi','error','⚠️\x20*Failed\x20','🌟\x20*BWM\x20XMD','u\x20vars:','HEROKU_APP','/apps/','he\x20bot\x20own','HtBuC','nstruction','to\x20update\x20','TO_REPLY=y','eroku\x20Vari','ronment\x20va','R_NAME=val','ting\x20Herok','ed\x20Success','BoRjt','for\x20your\x20b','📋\x20*Usage\x20I','hing\x20Herok','ne\x20minute\x20','/adams','Use\x20`AUTO_','=*\x20','PRaJd','8071944jaGqio','🚫\x20*Access\x20','5334335HZSigk','getallvar','🔑\x20*','ariable\x20or','sVRLk','he\x20bot!*','*\x20🌟\x0a\x0a','SMNUI','*BWM\x20XMD\x20V','ue`\x0a\x0a','entries','6JYAWGg','format.','dynos:',':*\x20','env','\x20restart\x20t','art!*','TO_REPLY=n','Denied!*\x20T','ariable:\x0a','CkoKo','get','/dynos','MAYrH','GITHUB_GIT','WMfQw','89374pLBnBj','Error\x20fetc','fully!*\x0a\x0a🔑','Heroku\x20env','1891692NgoJqc','\x0a\x0a🔄\x20*Just\x20','heroku-cli','Control','split','setvar','ot\x20to\x20rest','aQuav','⚠️\x20*Invalid','7otnUCo','tiUxR','s:*\x0a\x0a','\x20VARS\x20LIST','update\x20a\x20v','BOT_OWNER','yVuRW','phmlr','d\x20is\x20restr','eroku\x20envi','gewHy','\x20format!*\x20','/config-va','ToyNC','pEWrL','estarting\x20','REPLY=no`\x20','46033955enNfXj','sendMessag','riables!*','Example:\x0a','patch','HEROKU_API','To\x20set\x20or\x20','delete','icted\x20to\x20t','../Ibrahim','es`\x0a'];_0x49cc=function(){return _0x32dfe5;};return _0x49cc();}adams({'nomCom':_0x45aa9e(0x107),'categorie':_0x45aa9e(0xb1)},async(_0x3af239,_0x529c4d,_0x100e1e)=>{const _0x34a67f=_0x45aa9e,_0x59b78b={'aQuav':function(_0x45e558,_0x58ef7e){return _0x45e558(_0x58ef7e);},'ToyNC':_0x34a67f(0x105)+_0x34a67f(0x119)+_0x34a67f(0xe1)+_0x34a67f(0xbf)+_0x34a67f(0xd0)+_0x34a67f(0xf1)+_0x34a67f(0xdf),'phmlr':_0x34a67f(0xed)+_0x34a67f(0xba)+_0x34a67f(0x10c),'tlRzh':_0x34a67f(0x122)+_0x34a67f(0xfe)+_0x34a67f(0xee),'CkoKo':_0x34a67f(0xec)+_0x34a67f(0xd5)+_0x34a67f(0xc0)+_0x34a67f(0xf7)+_0x34a67f(0xca)},{repondre:_0x26c107,superUser:_0x3cf613}=_0x100e1e;if(!_0x3cf613)return _0x59b78b[_0x34a67f(0xb5)](_0x26c107,_0x59b78b[_0x34a67f(0xc4)]);try{const _0x3827ce=await heroku[_0x34a67f(0x11c)](_0x34a67f(0xf0)+appName+(_0x34a67f(0xc3)+'rs'));let _0x433ca6=_0x59b78b[_0x34a67f(0xbe)];for(const [_0x35279a,_0x2dc3fe]of Object[_0x34a67f(0x110)](_0x3827ce)){_0x433ca6+=_0x34a67f(0x108)+_0x35279a+_0x34a67f(0x102)+_0x2dc3fe+'\x0a';}await _0x529c4d[_0x34a67f(0xc9)+'e'](_0x3af239,{'text':_0x433ca6});}catch(_0x27cbad){console[_0x34a67f(0xeb)](_0x59b78b[_0x34a67f(0xe4)],_0x27cbad),await _0x529c4d[_0x34a67f(0xc9)+'e'](_0x3af239,{'text':_0x59b78b[_0x34a67f(0x11b)]});}}),adams({'nomCom':_0x45aa9e(0xb3),'categorie':_0x45aa9e(0xb1)},async(_0x145c6a,_0x234b9f,_0x1fd086)=>{const _0x5a22ed=_0x45aa9e,_0x287c5e={'sVRLk':function(_0x3a5223,_0x299f0f){return _0x3a5223(_0x299f0f);},'HSTNE':_0x5a22ed(0x105)+_0x5a22ed(0x119)+_0x5a22ed(0xe1)+_0x5a22ed(0xbf)+_0x5a22ed(0xd0)+_0x5a22ed(0xf1)+_0x5a22ed(0xdf),'KsmtK':function(_0x4872ad,_0xe7bad8){return _0x4872ad(_0xe7bad8);},'tiUxR':function(_0x186ce4,_0x374085){return _0x186ce4+_0x374085;},'gewHy':function(_0x190576,_0x1eade8){return _0x190576+_0x1eade8;},'uqxld':_0x5a22ed(0xfd)+_0x5a22ed(0xf3)+_0x5a22ed(0xb9),'yVuRW':_0x5a22ed(0xce)+_0x5a22ed(0xbb)+_0x5a22ed(0x11a),'BoRjt':_0x5a22ed(0xdd)+_0x5a22ed(0xf8)+_0x5a22ed(0x10f),'PRaJd':_0x5a22ed(0xcb),'SMNUI':_0x5a22ed(0xe2)+_0x5a22ed(0xf5)+_0x5a22ed(0xd2),'MAYrH':_0x5a22ed(0xe2)+_0x5a22ed(0x118)+'o`','HtBuC':function(_0x2918ae,_0x24e193){return _0x2918ae||_0x24e193;},'WMfQw':_0x5a22ed(0xb6)+_0x5a22ed(0xc2)+_0x5a22ed(0x101)+_0x5a22ed(0xc7)+_0x5a22ed(0x112),'ckguQ':_0x5a22ed(0xd6)+_0x5a22ed(0xf9)+_0x5a22ed(0xda)+_0x5a22ed(0xc6)+_0x5a22ed(0x113),'pEWrL':_0x5a22ed(0xec)+_0x5a22ed(0xf4)+_0x5a22ed(0x124)+_0x5a22ed(0xe5)+_0x5a22ed(0x109)+_0x5a22ed(0x116)+_0x5a22ed(0x10b)},{ms:_0x493ba4,repondre:_0x36a374,superUser:_0x48c6cf,arg:_0x6c7412}=_0x1fd086;if(!_0x48c6cf)return _0x287c5e[_0x5a22ed(0x10a)](_0x36a374,_0x287c5e[_0x5a22ed(0xd8)]);if(!_0x6c7412[-0x22dd+0xc35+0x16a8]||!_0x6c7412[-0x124b+-0xb0b+0x1d56][_0x5a22ed(0xdc)]('='))return _0x287c5e[_0x5a22ed(0xd7)](_0x36a374,_0x287c5e[_0x5a22ed(0xb8)](_0x287c5e[_0x5a22ed(0xb8)](_0x287c5e[_0x5a22ed(0xc1)](_0x287c5e[_0x5a22ed(0xc1)](_0x287c5e[_0x5a22ed(0xc1)](_0x287c5e[_0x5a22ed(0xe9)],_0x287c5e[_0x5a22ed(0xbd)]),_0x287c5e[_0x5a22ed(0xfb)]),_0x287c5e[_0x5a22ed(0x103)]),_0x287c5e[_0x5a22ed(0x10d)]),_0x287c5e[_0x5a22ed(0x11e)]));const [_0x4a3a28,_0x2747c9]=_0x6c7412[0x1*0x2b8+-0x1835+-0x1*-0x157d][_0x5a22ed(0xb2)]('=');if(_0x287c5e[_0x5a22ed(0xf2)](!_0x4a3a28,!_0x2747c9))return _0x287c5e[_0x5a22ed(0xd7)](_0x36a374,_0x287c5e[_0x5a22ed(0x120)]);try{const _0x1408ef=await heroku[_0x5a22ed(0xcc)](_0x5a22ed(0xf0)+appName+(_0x5a22ed(0xc3)+'rs'),{'body':{[_0x4a3a28]:_0x2747c9}}),_0x321b17=_0x1408ef[_0x4a3a28];await heroku[_0x5a22ed(0xcf)](_0x5a22ed(0xf0)+appName+_0x5a22ed(0x11d));const _0x4dcc9b=await heroku[_0x5a22ed(0x11c)](_0x5a22ed(0xf0)+appName+(_0x5a22ed(0xc3)+'rs')),_0x2c95f7=_0x4dcc9b[_0x4a3a28];await _0x234b9f[_0x5a22ed(0xc9)+'e'](_0x145c6a,{'text':_0x5a22ed(0x10e)+_0x5a22ed(0xd9)+_0x5a22ed(0xf6)+_0x5a22ed(0xe6)+_0x5a22ed(0xfa)+_0x5a22ed(0x123)+'\x20*'+_0x4a3a28+_0x5a22ed(0x114)+_0x2c95f7+(_0x5a22ed(0xaf)+_0x5a22ed(0xe0)+_0x5a22ed(0xff)+_0x5a22ed(0xfc)+_0x5a22ed(0xb4)+_0x5a22ed(0x117))});}catch(_0x2a4a07){console[_0x5a22ed(0xeb)](_0x287c5e[_0x5a22ed(0xe8)],_0x2a4a07),await _0x234b9f[_0x5a22ed(0xc9)+'e'](_0x145c6a,{'text':_0x287c5e[_0x5a22ed(0xc5)]});}});


/**const { adams } = require("../Ibrahim/adams");
const Heroku = require('heroku-client');
const { readdirSync } = require('fs');

const heroku = new Heroku({ token: process.env.HEROKU_API_KEY });
const appName = process.env.HEROKU_APP_NAME;
const BaseUrl = process.env.GITHUB_GIT;
const adamsapikey = process.env.BOT_OWNER;
// Command to display all Heroku environment variables
adams({
  nomCom: 'getallvar',
  categorie: "Control"
}, async (chatId, zk, context) => {
  const { repondre, superUser } = context;

  // Ensure the command is executed by the bot owner
  if (!superUser) {
    return repondre("🚫 *Access Denied!* This command is restricted to the bot owner.");
  }

  // Fetch all Heroku environment variables
  try {
    const configVars = await heroku.get(`/apps/${appName}/config-vars`);
    let message = "🌟 *BWM XMD VARS LIST* 🌟\n\n";
    for (const [key, value] of Object.entries(configVars)) {
      message += `🔑 *${key}=* ${value}\n`;
    }
    await zk.sendMessage(chatId, { text: message });
  } catch (error) {
    console.error("Error fetching Heroku vars:", error);
    await zk.sendMessage(chatId, { text: "⚠️ *Failed to fetch Heroku environment variables!*" });
  }
});

// Command to set or update Heroku environment variables
adams({
  nomCom: 'setvar',
  categorie: "Control"
}, async (chatId, zk, context) => {
  const { ms, repondre, superUser, arg } = context;

  // Ensure the command is executed by the bot owner
  if (!superUser) {
    return repondre("🚫 *Access Denied!* This command is restricted to the bot owner.");
  }

  // Validate input
  if (!arg[0] || !arg[0].includes('=')) {
    return repondre(
      "📋 *Usage Instructions:*\n\n" +
      "To set or update a variable:\n" +
      "`setvar VAR_NAME=value`\n\n" +
      "Example:\n" +
      "`setvar AUTO_REPLY=yes`\n" +
      "`setvar AUTO_REPLY=no`"
    );
  }

  // Parse variable and value
  const [varName, value] = arg[0].split('=');
  if (!varName || !value) {
    return repondre("⚠️ *Invalid format!* Use `AUTO_REPLY=no` format.");
  }

  // Update Heroku environment variable
  try {
    const updateResponse = await heroku.patch(`/apps/${appName}/config-vars`, {
      body: {
        [varName]: value
      }
    });

    const updatedValue = updateResponse[varName];

    // Restart Heroku dynos after update
    await heroku.delete(`/apps/${appName}/dynos`);

    // Confirm the updated value after restart
    const configVars = await heroku.get(`/apps/${appName}/config-vars`);
    const appliedValue = configVars[varName];

    await zk.sendMessage(chatId, {
      text: `*BWM XMD VARS*\n\n✅ *Heroku Variable Updated Successfully!*\n\n🔑 *${varName}:* ${appliedValue}\n\n🔄 *Just wait for one minute for your bot to restart!*`
    });
  } catch (error) {
    console.error("Error updating Heroku var or restarting dynos:", error);
    await zk.sendMessage(chatId, { text: "⚠️ *Failed to update Heroku environment variable or restart the bot!*" });
  }
});
**/
