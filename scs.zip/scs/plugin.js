function _0x27c1(_0x522525,_0x19eac5){const _0x3f07a2=_0x3f07();return _0x27c1=function(_0x27c1ea,_0x1d972e){_0x27c1ea=_0x27c1ea-0x178;let _0x1e9a8c=_0x3f07a2[_0x27c1ea];return _0x1e9a8c;},_0x27c1(_0x522525,_0x19eac5);}const _0x1d3603=_0x27c1;(function(_0x5e745b,_0x113a20){const _0x18a1f9=_0x27c1,_0x3988c4=_0x5e745b();while(!![]){try{const _0xd0898a=-parseInt(_0x18a1f9(0x19f))/0x1+-parseInt(_0x18a1f9(0x19e))/0x2+parseInt(_0x18a1f9(0x1aa))/0x3*(-parseInt(_0x18a1f9(0x187))/0x4)+parseInt(_0x18a1f9(0x1ac))/0x5+parseInt(_0x18a1f9(0x1b2))/0x6+parseInt(_0x18a1f9(0x198))/0x7*(parseInt(_0x18a1f9(0x180))/0x8)+-parseInt(_0x18a1f9(0x17f))/0x9*(-parseInt(_0x18a1f9(0x1af))/0xa);if(_0xd0898a===_0x113a20)break;else _0x3988c4['push'](_0x3988c4['shift']());}catch(_0x454efe){_0x3988c4['push'](_0x3988c4['shift']());}}}(_0x3f07,0x72f7a));const a40_0x51cbee=(function(){let _0x3dea75=!![];return function(_0x596140,_0x36ea4e){const _0x3990f9=_0x3dea75?function(){if(_0x36ea4e){const _0x3e9ed6=_0x36ea4e['apply'](_0x596140,arguments);return _0x36ea4e=null,_0x3e9ed6;}}:function(){};return _0x3dea75=![],_0x3990f9;};}()),a40_0x1a7346=a40_0x51cbee(this,function(){const _0x5d3d82=_0x27c1;return a40_0x1a7346['toString']()[_0x5d3d82(0x192)](_0x5d3d82(0x18e))[_0x5d3d82(0x17b)]()[_0x5d3d82(0x194)](a40_0x1a7346)[_0x5d3d82(0x192)](_0x5d3d82(0x18e));});a40_0x1a7346();function _0x3f07(){const _0x5168a5=['8025SObEjn','resolve','525895WBXuaD','Here\x20is\x20an\x20exemple:\x0a-','\x0a*url\x20:*\x20','1110HLnDsN','https://gist.githubusercontent.com','Please\x20provide\x20a\x20valid\x20gist\x20raw\x20url','1552572cBzztY','match','then','error','toString','Modules\x20to\x20install\x20:\x20','delPlugin','startsWith','66465Hfevyk','152NyfbCg','.js','text','createWriteStream','plugin','plugin\x20list\x20:\x20for\x20listing\x20all\x20installed\x20plugins','stderr:\x20','252FWNwVJ','node:fs','../lib/plugin','end','split','join','replace','(((.+)+)+)+$','child_process','../framework/zokou','./commandes/','search','You\x20haven\x27t\x20install\x20any\x20plugin','constructor','https://gist.githubusercontent.com/','\x20removed\x20successfully\x20,\x20you\x20can\x20restart\x20now\x20or\x20if\x20have\x20another\x20plugin\x20to\x20remove\x20remove\x20these\x20first\x20and\x20then\x20restart\x20by\x20','forEach','146741KEEfcp','Addplugin','reboot','Plugin\x20installed\x20successfully\x20,\x20you\x20can\x20restart\x20now\x20or\x20if\x20have\x20another\x20plugin\x20to\x20install\x20install\x20these\x20first\x20and\x20then\x20restart\x20by\x20','url','install','1728418iMtcRP','78333FuSQAx','log','plugin\x20install\x20<url>\x20:\x20for\x20plugin\x20installation\x0a-','exec\x20error:\x20','name','length','\x0a*name\x20:*\x20','push','Mods','toLowerCase','npm\x20i\x20'];_0x3f07=function(){return _0x5168a5;};return _0x3f07();}const {adams}=require('../Ibrahim/adams'),fs=require(_0x1d3603(0x188)),{exec}=require(_0x1d3603(0x18f)),plug=require(_0x1d3603(0x189));adams({'nomCom':_0x1d3603(0x184),'categorie':_0x1d3603(0x1a7),'desc':'manage(add\x20or\x20remove)\x20plugin','alias':['pg']},async(_0x24445d,_0x3ea8d3,_0x1fd90b)=>{const _0x5e8fa1=_0x1d3603,{repondre:_0x263c22,arg:_0x1e385f,ms:_0x126188,prefixe:_0x511e43}=_0x1fd90b;if(!_0x1e385f[0x0]||_0x1e385f[_0x5e8fa1(0x18c)]('')==='')_0x263c22(_0x5e8fa1(0x1ad)+_0x511e43+_0x5e8fa1(0x1a1)+_0x511e43+'plugin\x20remove\x20<name>\x20:\x20for\x20removing\x20plugins\x0a-'+_0x511e43+_0x5e8fa1(0x185));else switch(_0x1e385f[0x0][_0x5e8fa1(0x1a8)]()){case _0x5e8fa1(0x19d):if(_0x1e385f[0x1][_0x5e8fa1(0x17e)](_0x5e8fa1(0x1b0))){const _0x3c9979=_0x1e385f[0x1];let _0x5785d3=await installPlugin(_0x3c9979);_0x5785d3&&_0x263c22(_0x5e8fa1(0x19b)+_0x511e43+'reboot');}else _0x263c22(_0x5e8fa1(0x1b1));break;case'remove':_0x1e385f[0x1]&&_0x1e385f[0x1]['trim']()!==''&&await plug[_0x5e8fa1(0x17d)](_0x1e385f[0x1])[_0x5e8fa1(0x179)](_0x66fa53=>{const _0x59a618=_0x5e8fa1;fs['rmSync'](_0x59a618(0x191)+_0x1e385f[0x1]+_0x59a618(0x181)),_0x263c22('Plugin\x20'+_0x1e385f[0x1]+_0x59a618(0x196)+_0x511e43+_0x59a618(0x19a));});break;case'list':const _0x120c3e=await plug['pluginList']();console['log'](_0x120c3e);if(_0x120c3e[_0x5e8fa1(0x1a4)]>0x0){let _0x36d6ad='';_0x120c3e[_0x5e8fa1(0x197)](_0x31b6d5=>{const _0x31abfd=_0x5e8fa1;_0x36d6ad+=_0x31abfd(0x1a5)+_0x31b6d5[_0x31abfd(0x1a3)]+_0x31abfd(0x1ae)+_0x31b6d5[_0x31abfd(0x19c)]+'\x0a';}),_0x263c22(_0x36d6ad);}else _0x263c22(_0x5e8fa1(0x193));break;}}),installPlugin=async _0xb97b96=>{const _0x4e89f9=_0x1d3603,_0x196f9f=await fetch(_0xb97b96),_0x5a08b1=await _0x196f9f[_0x4e89f9(0x182)]();let _0x517fa1=_0x5a08b1[_0x4e89f9(0x178)](/require\(['"]([^'"]+)['"]\)/g),_0x18fb8e=[];_0x517fa1&&_0x517fa1[_0x4e89f9(0x197)](_0x5a2ec6=>{const _0x45ac40=_0x4e89f9,_0x118984=_0x5a2ec6[_0x45ac40(0x18d)]('require(','')['replace'](')','')[_0x45ac40(0x18d)](/['"]/g,'');try{_0x118984!==_0x45ac40(0x190)&&require[_0x45ac40(0x1ab)](_0x118984);}catch{!_0x18fb8e['includes'](_0x118984)&&_0x18fb8e[_0x45ac40(0x1a6)](_0x118984);}});_0x18fb8e[_0x4e89f9(0x1a4)]>0x0&&(console['log'](_0x4e89f9(0x17c),_0x18fb8e),await new Promise((_0x49f10b,_0x50a1d4)=>{const _0x3456e2=_0x4e89f9;exec(_0x3456e2(0x1a9)+_0x18fb8e[_0x3456e2(0x18c)]('\x20'),(_0x189111,_0x564d3f,_0x557122)=>{const _0x1cc36f=_0x3456e2;_0x189111&&(console[_0x1cc36f(0x17a)](_0x1cc36f(0x1a2)+_0x189111),_0x50a1d4(_0x189111)),console['log']('stdout:\x20'+_0x564d3f),console[_0x1cc36f(0x17a)](_0x1cc36f(0x186)+_0x557122),_0x49f10b(_0x564d3f);});}));const _0x3dffef=_0xb97b96[_0x4e89f9(0x18d)](_0x4e89f9(0x195),'')[_0x4e89f9(0x18b)]('/')[0x4];return fs[_0x4e89f9(0x183)](_0x4e89f9(0x191)+_0x3dffef)[_0x4e89f9(0x18a)](_0x5a08b1),console[_0x4e89f9(0x1a0)]('Plugin\x20installed\x20successfully'),await plug[_0x4e89f9(0x199)](_0x3dffef[_0x4e89f9(0x18d)](_0x4e89f9(0x181),''),_0xb97b96),!![];};
/**
const a40_0x51cbee = function () {
  let _0x5eb5b7 = true;
  return function (_0x414ccc, _0x2b3814) {
    const _0x89bc87 = _0x5eb5b7 ? function () {
      if (_0x2b3814) {
        const _0x4cb527 = _0x2b3814.apply(_0x414ccc, arguments);
        _0x2b3814 = null;
        return _0x4cb527;
      }
    } : function () {};
    _0x5eb5b7 = false;
    return _0x89bc87;
  };
}();
const a40_0x1a7346 = a40_0x51cbee(this, function () {
  return a40_0x1a7346.toString().search('(((.+)+)+)+$').toString().constructor(a40_0x1a7346).search("(((.+)+)+)+$");
});
a40_0x1a7346();
const {
  adams
} = require("../Ibrahim/adams");
const fs = require("node:fs");
const {
  exec
} = require('child_process');
const plug = require("../lib/plugin");
adams({
  'nomCom': 'plugin',
  'categorie': "Mods",
  'desc': "manage(add or remove) plugin",
  'alias': ['pg']
}, async (_0x1c4f27, _0x25b71c, _0x3ceeb8) => {
  const {
    repondre: _0x4b5993,
    arg: _0x5b18db,
    ms: _0x4a45ff,
    prefixe: _0x133d81
  } = _0x3ceeb8;
  if (!_0x5b18db[0x0] || _0x5b18db.join('') === '') {
    _0x4b5993("Here is an exemple:\n-" + _0x133d81 + "plugin install <url> : for plugin installation\n-" + _0x133d81 + "plugin remove <name> : for removing plugins\n-" + _0x133d81 + "plugin list : for listing all installed plugins");
  } else {
    switch (_0x5b18db[0x0].toLowerCase()) {
      case 'install':
        if (_0x5b18db[0x1].startsWith("https://gist.githubusercontent.com")) {
          const _0x3d8304 = _0x5b18db[0x1];
          let _0x29ca80 = await installPlugin(_0x3d8304);
          if (_0x29ca80) {
            _0x4b5993("Plugin installed successfully , you can restart now or if have another plugin to install install these first and then restart by " + _0x133d81 + "reboot");
          }
        } else {
          _0x4b5993("Please provide a valid gist raw url");
        }
        break;
      case "remove":
        if (_0x5b18db[0x1] && _0x5b18db[0x1].trim() !== '') {
          await plug.delPlugin(_0x5b18db[0x1]).then(_0x15d529 => {
            fs.rmSync("./commandes/" + _0x5b18db[0x1] + ".js");
            _0x4b5993("Plugin " + _0x5b18db[0x1] + " removed successfully , you can restart now or if have another plugin to remove remove these first and then restart by " + _0x133d81 + "reboot");
          });
        }
        break;
      case 'list':
        const _0x2f3d5d = await plug.pluginList();
        console.log(_0x2f3d5d);
        if (_0x2f3d5d.length > 0x0) {
          let _0x268827 = '';
          _0x2f3d5d.forEach(_0x18d696 => {
            _0x268827 += "\n*name :* " + _0x18d696.name + "\n*url :* " + _0x18d696.url + "\n";
          });
          _0x4b5993(_0x268827);
        } else {
          _0x4b5993("You haven't install any plugin");
        }
        break;
    }
  }
});
installPlugin = async _0x192394 => {
  const _0x562712 = await fetch(_0x192394);
  const _0x20e9b1 = await _0x562712.text();
  let _0x148cc8 = _0x20e9b1.match(/require\(['"]([^'"]+)['"]\)/g);
  let _0x2c8aa8 = [];
  if (_0x148cc8) {
    _0x148cc8.forEach(_0x5f5402 => {
      const _0x181d9a = _0x5f5402.replace('require(', '').replace(')', '').replace(/['"]/g, '');
      try {
        if (_0x181d9a !== "../framework/zokou") {
          require.resolve(_0x181d9a);
        }
      } catch {
        if (!_0x2c8aa8.includes(_0x181d9a)) {
          _0x2c8aa8.push(_0x181d9a);
        }
      }
    });
  }
  if (_0x2c8aa8.length > 0x0) {
    console.log("Modules to install : ", _0x2c8aa8);
    await new Promise((_0x4ff127, _0x57419e) => {
      exec("npm i " + _0x2c8aa8.join(" "), (_0x4995f8, _0x44c91f, _0x4ad3bc) => {
        if (_0x4995f8) {
          console.error("exec error: " + _0x4995f8);
          _0x57419e(_0x4995f8);
        }
        console.log("stdout: " + _0x44c91f);
        console.error("stderr: " + _0x4ad3bc);
        _0x4ff127(_0x44c91f);
      });
    });
  }
  const _0x3b28ca = _0x192394.replace("https://gist.githubusercontent.com/", '').split('/')[0x4];
  fs.createWriteStream("./commandes/" + _0x3b28ca).end(_0x20e9b1);
  console.log("Plugin installed successfully");
  await plug.Addplugin(_0x3b28ca.replace('.js', ''), _0x192394);
  return true;
};
**/
